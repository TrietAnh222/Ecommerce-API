const jwt = require('jsonwebtoken');

module.exports = async function (req, res, proceed) {
    // Check if the request has a token in the authorization header
    const authHeader = req.headers.authorization; 
    if (!authHeader) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    try {
      const token = authHeader.split(' ')[1];
      // Verify the token using the secret key
      const auth = jwt.verify(token, process.env.JWT_SECRET);
      // Attach the decoded token (user info) to the request object
      req.auth = auth;
      // User is authenticated, proceed to the next policy or controller
      return proceed();
    } catch (error) {
      return res.status(401).json({ error: 'Invalid token' });
    }
  };