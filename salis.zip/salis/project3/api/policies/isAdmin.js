const jwt = require('jsonwebtoken');

module.exports = async function (req, res, proceed) {
  console.log('IsAdmin')
    // Kiểm tra nếu yêu cầu có chứa token trong header Authorization
    const authHeader = req.headers.authorization;
    console.log(authHeader)
    if (!authHeader) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    try {
    const token = authHeader.split(' ')[1];
      // Xác minh token bằng secret key
      const auth = jwt.verify(token, process.env.JWT_SECRET);
      // Đính kèm thông tin đã giải mã từ token vào đối tượng request
      // Kiểm tra vai trò của người dùng
      if (!auth.role || auth.role !== 'admin') {
        return res.status(403).json({ error: 'Forbidden: Insufficient privileges' });
      }
      // Attach the decoded token (user info) to the request object
      req.auth = auth;
      // Người dùng có vai trò admin, tiếp tục đến policy hoặc controller tiếp theo
      return proceed();
    } catch (error) {
      // Xử lý các lỗi khác nhau
      if (error.name === 'TokenExpiredError') {
        return res.status(401).json({ error: 'Token expired' });
      } else if (error.name === 'JsonWebTokenError') {
        return res.status(401).json({ error: 'Invalid token' });
      } else {
        return res.status(500).json({ error: 'Internal server error', detail: error.message });
      }
    }
  };
  