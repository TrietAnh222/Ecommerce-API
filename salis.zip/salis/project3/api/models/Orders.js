module.exports = {
    user:{
        model: 'User',
        required: true
    },
    username:{
        type: 'string',
        required: true
    },
    totalprice:{
        type: 'number',
        required: true,
    },
    status: {
        type: 'string',
        isIn: ['pending', 'completed', 'canceled'],
        defaultsTo: 'pending',
      },
    products: {
        collection: 'product',
        via: 'orders' // Giả sử bạn có thiết lập liên kết 2 chiều trong Product model
    }
}