module.exports = {
    attributes: {
      name: {
        type: 'string',
        required: true,
        unique: true
      },
      password:{
        type: 'string',
        required: true,
      },
      devices: {
        collection: 'UserDevices',
        via: 'user'
      },
      role:{
        type: 'string',
        isIn: ['admin','user'],
        defaultsTo: 'user'
      },
      refreshToken: { type: 'string' }
    },
}