module.exports = {
    attributes: {
      user: {
        model: 'User',
        required: true
      },
      deviceToken: {
        type: 'string',
        required: true,
        unique: true,
      }
    }
  };