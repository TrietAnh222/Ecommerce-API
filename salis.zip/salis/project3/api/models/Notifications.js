module.exports = {
    attributes: {
      title: {
        type: 'string',
        required: true
      },
      body: {
        type: 'string',
        required: true
      },
      user: {
        model: 'User', // Liên kết với User
        required: true
      },
    }
  };