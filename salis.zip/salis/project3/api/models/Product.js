module.exports = {
    attributes: {
        name: {
            type: 'string',
            required: true,
            unique: true
        },
        price: {
            type: 'number',
            required: true,
            custom: (value) => {
                // Kiểm tra xem giá trị có phải là số nguyên dương hay không
                return Number.isInteger(value) && value > 0;
            }
        },
        producttype: {
            type: 'string',
            required: true,
        },
        quantity: {
            type: 'number',
            required: true,
            custom: (value) => {
                // Kiểm tra xem giá trị có phải là số nguyên dương hay không
                return Number.isInteger(value) && value > 0;
            }
        }
    }
}