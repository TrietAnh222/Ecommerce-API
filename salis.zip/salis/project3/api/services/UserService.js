const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const createUser = async ({ name, password, role }) => {
  // Hash the password
  const hashedPassword = await bcrypt.hash(password, 10);

  // Create the user with the hashed password
  const user = await User.create({ name, password: hashedPassword, role }).fetch();
  return user;
};

const authenticateUser = async ({ name, password }) => {
  // Find the user by name
  const checkUser = await User.findOne({ name });
  if (!checkUser) {
    throw new Error('User not found');
  }
  // Check the password
  const checkPassword = await bcrypt.compare(password, checkUser.password);
  if (!checkPassword) {
    throw new Error('User or password is not correct');
  }

  // Create the token
  const token = jwt.sign(
    { userId: checkUser.id, role: checkUser.role },
    process.env.JWT_SECRET,
    { expiresIn: '1h' } // Token expires in 1 hour
  );

  const refreshToken = jwt.sign(
    { userId: checkUser.id, role: checkUser.role },
    process.env.REFRESH_TOKEN_SECRET,
    { expiresIn: '7d' } // Refresh token expires in 7 days
  );
  return { token, refreshToken };
};
module.exports = {
  createUser,
  authenticateUser
};
