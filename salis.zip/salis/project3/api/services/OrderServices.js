const ProductService = require('./Productservices')

const create = async (userId,items) => {
    const user = await User.findOne({id: userId});
    if (!user) {
        throw new Error('User not found');
    }
     // Lấy thông tin các sản phẩm
    const productIds = items.map(item => item.id);
    const products = await Product.find({ id: productIds });

    if (products.length !== items.length) {
        throw new Error('Some products not found');
      }
      // Tính toán tổng giá
    let totalPrice = 0;
    items.forEach(async item => {
      const product = products.find(p => p.id === item.id);
      if (product) {
        totalPrice += product.price * item.quantity; 
      }
      // Kiểm tra số lượng tồn kho
      if (product.quantity < item.quantity) {
        throw new Error(`Insufficient stock for product ${product.name}`);
      }
      if(item.quantity <= 0 ){
        throw new Error('quantity must be number larger than 1')
      }
      await ProductService.update(product.id, {
        quantity: product.quantity - item.quantity,
      });
    });
    // Tạo đơn hàng mới với các sản phẩm
    const newOrder = await Orders.create({
        user: user.id,
        customerName: user.username,
        totalPrice,
        products: items.map(item => ({ product: item.id, quantity: item.quantity })), // Liên kết với các sản phẩm và số lượng
      }).fetch();
      return newOrder;
}
const find = async (UserId) => {
  const userOrder = await Orders.find({user: UserId})
  return userOrder;
}
module.exports = {
    create,
    find
}