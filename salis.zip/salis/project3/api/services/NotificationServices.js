const admin = require('firebase-admin');

module.exports = {
  sendNotificationToUser: async function (userId, title, body) {
    try {
      // Tìm user và lấy tất cả các thiết bị của user đó
      const user = await User.findOne({ id: userId }).populate('devices');
      if (!user || !user.id ){
        throw new Error('User not Found')
      }
      // Tạo danh sách các device tokens
      const tokens = user.devices.map(device => device.deviceToken);
      if (tokens.length === 0) {
        throw new Error('No devices found for the user');
      }

      // Lưu thông báo vào database
      const notification = await Notifications.create({
        title,
        body,
        user: userId
      }).fetch();

      // Gửi thông báo đến tất cả các thiết bị
      const message = {
        notification: {
          title: notification.title,
          body: notification.body,
        },
        tokens: tokens, // Gửi đến nhiều device tokens
      };

      const response = await admin.messaging().sendEachForMulticast(message);

      // Cập nhật trạng thái của thông báo trong database
      await Notifications.update({ id: notification.id }).set({
        status: response.failureCount > 0 ? 'failed' : 'sent'
      });
      return response;
    } catch (error) {
      throw new Error(`Failed to send notification: ${error.message}`);
    }
  }
};
