const create = async ({ name, price, producttype, quantity }) => {
    const product = await Product.create({ name, price, producttype, quantity }).fetch();
    return product
}
const findall = async (limit, skip) => {
    const products = await Product.find().limit(limit).skip(skip)
    return products
}
const findType = async (producttype, limit, skip) => {
    const products = await Product.find({ producttype })
        .limit(limit)  // Giới hạn số lượng bản ghi trả về
        .skip(skip)    // Bỏ qua một số bản ghi nhất định
    return products;
}
const update = async (productId, updates) => {
    //kiểm tra xem sản phẩm có tồn tại không
    const checkProduct = await Product.findOne({ id: productId });
    if (!checkProduct) {
        throw new Error('product not found');
    }
    // Tạo đối tượng cập nhật với các trường cần thiết
    const updatedFields = {};

    if (updates.name && updates.name.trim() !== '') {
      updatedFields.name = updates.name;
    }

    if (Number.isFinite(updates.price) && updates.price > 0) {
      updatedFields.price = updates.price;
    }

    if (Number.isInteger(updates.quantity) && updates.quantity > 0) {
      updatedFields.quantity = updates.quantity;
    }
    const updatedProduct = await Product.update({ id: productId }).set(updatedFields).fetch();
    return updatedProduct
}
module.exports = {
    create,
    findall,
    findType,
    update
}