const OrderService = require('../services/OrderServices')

const create = async (req, res) => {
    try {
        const { items } = req.body;
        const userId = req.auth.userId;
        // Kiểm tra xem các trường cần thiết có tồn tại không
        if (!userId || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'Invalid input' });
        }
        // Sử dụng service để tạo đơn hàng
        const newOrder = await OrderService.create(userId, items);

        return res.status(201).json(newOrder);
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
}
const find = async (req, res) => {
    try {
        const userId = req.auth.userId;
        if (!userId) {
            return res.status(400).json({ error: 'user not defined' });
        }
        const userOrder = await OrderService.find(userId);
        return res.status(201).json(userOrder);                                               
    } catch (error) {
        return res.status(500).json({ error: error.message });
    }
}
module.exports = {
    create,
    find
}