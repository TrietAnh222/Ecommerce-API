const ProductService = require('../services/Productservices');
//tạo sản phẩm
const create = async (req, res) => {
    try {
        const { name,price,quantity } = req.body
        const producttype = req.body.producttype.toLowerCase()
        const product = await ProductService.create({ name, price, producttype,quantity })
        return res.status(201).json(product);
    } catch (error) {
        return res.status(500).json({ error: 'Failed to create product', details: error.message });
    }
}
//tìm tất cả
const findall = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = 3;
        const skip = (page - 1) * limit;
        const allproducts = await ProductService.findall(limit, skip)
        return res.status(201).json(allproducts)
    } catch (error) {
        console.log(error)
        return res.status(500).json({ error: 'Failed to find product', details: error});
    }
}
//tìm theo loại
const findType = async (req, res) => {
    try {
        const producttype  = req.params.producttype.toLowerCase();
        const page = parseInt(req.query.page) || 1;
        const limit = 3;
        const skip = (page - 1) * limit;
        const allproducts = await ProductService.findType(producttype, limit, skip)
        if(!allproducts){
            return res.status(404).json({error: 'producttype not found'})
        }
        return res.status(201).json(allproducts)
    } catch (error) {
        return res.status(500).json({ error: 'Failed to find product', details: error.message });
    }
}
const update = async (req, res) => {
    try {
        const productId = req.params.id; // Giả sử bạn truyền ID sản phẩm trong URL
        const updates = req.body; // Dữ liệu để cập nhật từ client

        // Gọi service để cập nhật sản phẩm
        const updatedProduct = await ProductService.update(productId, updates);

        // Kiểm tra nếu sản phẩm không được tìm thấy
        if (updatedProduct.length === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }

        return res.status(200).json(updatedProduct);
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
}
module.exports = {
    create,
    findall,
    findType,
    update
}