module.exports = {
  //tạo 1 thiết bị
  create: async function (req, res) {
    try {
      const { deviceToken } = req.body;
      const userId = req.auth.userId
      // Validate the input
      if (!userId || !deviceToken) {
        return res.status(400).json({ error: 'Missing userId or deviceToken' });
      }
      // check user exist
      const checkUser = await User.findOne({ id: userId })
      if (!checkUser) {
        return res.status(404).json({ error: 'User not found' });
      }
      //make a new device  
      const device = await UserDevices.create({
        user: userId,
        deviceToken,
      }).fetch();

      return res.json(device);

    } catch (error) {
      return res.status(500).json({ error: 'Failed to create device', details: error.message });
    }
  },
  //tìm tất cả thiết bị
  find: async function (req, res) {
    try {
      const page = parseInt(req.query.page) || 1; //số trang, mặc định là 1
      const limit = 10; // Số lượng thông báo mỗi trang
      const skip = (page - 1) * limit;//số lượng thông báo cần bỏ qua
      //hàm tìm thiết bị
      const devices = await UserDevices.find().sort('createdAt DESC').limit(limit).skip(skip)
      return res.json(devices);
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch devices', details: error.message });
    }
  },
};
