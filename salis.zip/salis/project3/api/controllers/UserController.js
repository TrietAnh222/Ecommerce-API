const UserService = require('../services/UserService');

const create = async (req, res) => {
  try {
    const { name, password, role } = req.body;
    // Validate input
    if (!name || !password) {
      return res.status(400).json({ error: 'Name and password are required' });
    }

    // Use the service to create the user
    const user = await UserService.createUser({ name, password, role });

    return res.status(201).json(user);
  } catch (error) {
    console.error('Failed to create user:', error);
    return res.status(500).json({ error: 'Failed to create user', details: error.message });
  }
};
//đăng nhập user
const login = async (req, res) => {
  try {
    const { name, password } = req.body;

    // Validate input
    if (!name || !password) {
      return res.status(400).json({ error: 'Name and password are required' });
    }

    // Use the service to authenticate the user
    const {token, refreshToken} = await UserService.authenticateUser({ name, password });
    await User.updateOne({ name:name }).set({ refreshToken });
    return res.status(200).json({ token,refreshToken });
  } catch (error) {
    console.error('Login error:', error);
    // Handle different error cases
    if (error.message === 'User not found' || error.message === 'User or password is not correct') {
      return res.status(401).json({ error: error.message });
    }
    return res.status(500).json({ error: 'Server error', message: error.message });
  }
};
//tìm tất cả user
const find = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 3; // Số lượng thông báo mỗi trang
    const skip = (page - 1) * limit;//số lượng thông báo cần bỏ qua
    const users = await User.find().populate('devices')
      .sort('createdAt DESC')
      .limit(limit)
      .skip(skip);
    return res.json(users);
  } catch (error) {
    return res.status(500).json({ error: 'Failed to fetch users', details: error.message });
  }
}
//cập nhật user
const update = async (req, res) => {
  try {
    const { userId, newname } = req.body
    const checkuser = await User.findOne({ id: userId })
    if (checkuser === null) {
      return res.status(404).json({ error: 'User not found' });
    }
    const updateduser = await User.update({ id: userId }).set({
      name: newname
    }).fetch();
    return res.json(updateduser);
  }
  catch (e) {
    return res.status(500).json({ error: 'Failed to update user', details: e.message });
  }
}
module.exports = {
  create,
  find,
  update,
  login
};
