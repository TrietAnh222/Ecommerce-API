const jwt = require('jsonwebtoken');

const refresh =  async function (req, res) {
    const refreshToken = req.body.refreshToken;

    if (!refreshToken) {
      return res.status(403).json({ error: 'Refresh token is required' });
    }

    try {
      const decoded = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET);
      const user = await User.findOne({ id: decoded.userId });

      if (!user) {
        return res.status(403).json({ error: 'Invalid refresh token' });
      }

      const newAccessToken = jwt.sign(
        { userId: user.id, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: '1h' }
      );

      return res.json({ accessToken: newAccessToken });
    } catch (error) {
      return res.status(403).json({ error: error.message });
    }
  }
module.exports = {
  refresh
}
