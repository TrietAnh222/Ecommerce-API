const NotificationServices = require('../services/NotificationServices')
module.exports = {
  //Gửi danh sách đến tất cả thiết bị mà người dúng đó đã đăng nhập vào
  sendNotification: async function (req, res) {
    console.log('this.sendNotification')
    try {
      const { title, body } = req.body;
      const userId = req.auth.userId
      //dùng service
      const response = await NotificationServices.sendNotificationToUser(userId, title, body);
      return res.json({ success: true, response });
    } catch (error) {
      return res.status(500).json({ error: 'Failed to send notification', details: error.message });
    }
  },
  findnotification: async function (req, res){
    try {
      const userId = req.auth.userId;
      // Lấy trang hiện tại từ query parameter, nếu không có thì mặc định là 1
      const page = parseInt(req.query.page) || 1;
      const limit = 10; // Số lượng thông báo mỗi trang
      const skip = (page - 1) * limit;//số lượng thông báo cần bỏ qua
      //hàm tìm kiếm theo trang
      const notifications = await Notifications.find({user: userId}).sort('createdAt DESC').limit(limit).skip(skip)
      return res.json(notifications);
    } catch (error) {
      return res.status(500).json({ error: 'Failed to fetch devices', details: error.message });
    }
  }
};