/**
 * Route Mappings
 * (sails.config.routes)
 *
 * Your routes tell Sails what to do each time it receives a request.
 *
 * For more information on configuring custom routes, check out:
 * https://sailsjs.com/anatomy/config/routes-js
 */

module.exports.routes = {

  /***************************************************************************
  *                                                                          *
  * Make the view located at `views/homepage.ejs` your home page.            *
  *                                                                          *
  * (Alternatively, remove this and add an `index.html` file in your         *
  * `assets` directory)                                                      *
  *                                                                          *
  ***************************************************************************/

  '/': { view: 'pages/homepage' },
 // UserController Routes
 'POST /user/create': 'UserController.create',
 'GET /user/find': 'UserController.find',
 'PATCH /user/update': 'UserController.update',
 'POST /user/login' : 'UserController.login',
 
 // UserDeviceController Routes
 'POST /user-device/create': 'UserDeviceController.create',
 'GET /user-device/find': 'UserDeviceController.find',

 // NotificationController Routes
 'POST /notification/send': 'NotificationController.sendNotification',
 'GET /notification/find': 'NotificationController.findNotification',

 // ProductController Routes
 'POST /product/create' : 'ProductController.create',
 'GET /product/findall' : 'ProductController.findall',
 'GET /product/type/:producttype': 'ProductController.findType',
 'PATCH /product/update/:id' : 'ProductController.update',
 
 //OrderController Routes
 'POST /order/create' : 'OrderController.create',
 'GET /order/find': 'OrderController.find',

 //refreshToken Routes
 'POST /refreshtoken/refresh': 'RefreshTokenController.refresh',
  /***************************************************************************
  *                                                                          *
  * More custom routes here...                                               *
  * (See https://sailsjs.com/config/routes for examples.)                    *
  *                                                                          *
  * If a request to a URL doesn't match any of the routes in this file, it   *
  * is matched against "shadow routes" (e.g. blueprint routes).  If it does  *
  * not match any of those, it is matched against static assets.             *
  *                                                                          *
  ***************************************************************************/


};
