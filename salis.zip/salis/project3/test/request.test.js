const axios = require('axios');

describe('Authentication API', () => {
  test('should return a token when valid username and password are provided', async () => {
    const credentials = {
      name: 'Farrow',
      password: '1231231231',
    };

    try {
      const res = await axios.post('http://localhost:1337/user/login', credentials); // Replace with your actual API URL
      // Assertions
      expect(res.status).toBe(200); // Ensure the status code is 200
      expect(res.data).toHaveProperty('token'); // Ensure the response has a 'token' property
      expect(typeof res.data.token).toBe('string'); // Ensure the token is a string
    } catch (error) {
      console.log(error.response ? error.response.data : error.message);
      throw error;
    }
  });
});
