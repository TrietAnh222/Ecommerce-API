var sails = require('sails');

module.exports = async () => {
  console.log('globalSetup');
  await new Promise((resolve, reject) => {
    sails.lift({
        port: 1337,
        environment: 'test',
        // datastores: {
        //     default: {
        //         adapter: 'sails-disk',
        //         inMemoryOnly: true
        //     }
        // },
        models: {
            migrate: 'safe', //'alter', 'drop'
        },
        hooks: {
            grunt: false
        },
        log: {
            // level: 'error'
            level: 'info'
        }
    },  (err) => {
        if (err) {
            console.error(err);
            process.exit()
        }
        return resolve('done');
    });
});
};


