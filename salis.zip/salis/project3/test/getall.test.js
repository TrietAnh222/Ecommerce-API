const axios = require('axios')

describe('tim tat ca nguoi dung va test cac truong hop sai', () => {
    let adminToken, nonAdminToken
    beforeAll(async () => {
        const adminResponse = await axios.post('http://localhost:1337/user/login', {
            name: 'Farrow',
            password: '1231231231',
        })
        adminToken = adminResponse.data.token
        const nonadminResponse = await axios.post('http://localhost:1337/user/login', {
            name: 'arrow',
            password: '1231231231',
        })
        nonAdminToken = nonadminResponse.data.token
    })
    it('admin có thể lấy danh sách người dùng', async () => {
    // Gọi API lấy danh sách người dùng bằng axios
    const response = await axios.get('http://localhost:1337/user/find', {
        headers: {
          Authorization: `Bearer ${adminToken}`, // Gửi token trong header
        },
      });
      // Kiểm tra phản hồi
      expect(response.status).toBe(200); // Đảm bảo API trả về status 200 OK
      expect(Array.isArray(response.data)).toBe(true); 
    }
    
    )
    it('người dùng bình thường không thể lấy danh sách',async () =>{
        try {
            // Gọi API với token của người dùng bình thường
            const response = await axios.get('http://localhost:1337/user/find', {
              headers: {
                Authorization: `Bearer ${nonAdminToken}`, // Gửi token của non-admin trong header
              },
            });
        
            // Nếu API không trả về lỗi, nghĩa là không đúng
            throw new Error('API không trả về lỗi như mong đợi', error.message);
        
          } catch (error) {
            // Kiểm tra lỗi và mã trạng thái
            expect(error.response.status).toBe(403); // Đảm bảo API trả về status 403 Forbidden
          }
    })
})