const axios = require('axios');

describe('DDoS Attack Simulation Test', () => {
  const baseUrl = 'http://localhost:1337/user/login';  // Thay đổi URL này thành endpoint cần test
  
  const credentials = {
    name: 'Farrow',
    password: '1231231231',
  };

  const sendRequests = async (numRequests) => {
    const promises = [];
    
    for (let i = 0; i < numRequests; i++) {
      promises.push(
        axios.post(baseUrl, credentials).catch(error => {
          // Bắt lỗi nếu server không phản hồi hoặc gặp quá tải
          console.error(`Request ${i + 1} failed:`, error.message);
        })
      );
    }
    // Gửi tất cả các requests cùng lúc bằng cách sử dụng Promise.all
    await Promise.all(promises);
  };
  it('should simulate a DDoS attack by sending multiple requests simultaneously', async () => {
    const numRequests = 250;  // Số lượng request bạn muốn gửi, giả lập một DDoS nhỏ
    
    console.log(`Sending ${numRequests} requests to ${baseUrl}`);

    const startTime = Date.now();
    await sendRequests(numRequests);
    const endTime = Date.now();

    console.log(`Total time for ${numRequests} requests: ${endTime - startTime} ms`);
  },30000);
});